"""Exact point operations in the source setting; translations retained for ID checks only."""
import json,copy,itertools,math
from pathlib import Path
import numpy as np
import sympy as S
from functools import lru_cache
ROOT=Path(__file__).parent
I=S.eye(3); sqrt3=S.sqrt(3)
HEX=S.Matrix([[1,-S.Rational(1,2),0],[0,sqrt3/2,0],[0,0,1]])
ORTH=S.eye(3)
DIRECTIONS={'x':(1,0,0),'y':(0,1,0),'z':(0,0,1),'xy':(1,1,0),'xby':(-1,1,0),'1':(1,-1,0),'2':(1,2,0),'3':(2,1,0)}
def normlabel(label):
 return label.replace('𝑥̅𝑦','xby').replace('6̅-1','6̅z-1').replace('6-1','6z-1')
@lru_cache(None)
def matrix(label,hexa=False):
 label=normlabel(label)
 if label=='1':return I
 if label=='1̅':return -I
 if label.startswith('m') or (label.startswith('2') and label!='2z'):
  d=S.Matrix(DIRECTIONS[label[1:]])
  if hexa:d=HEX*d
  C=2*d*d.T/(d.dot(d))-I
  return S.simplify(-C if label.startswith('m') else C)
 inv='̅'in label;n=int(label[0]);sgn=-1 if label.endswith('-1') else 1
 a=sgn*2*S.pi/n
 C=S.Matrix([[S.cos(a),-S.sin(a),0],[S.sin(a),S.cos(a),0],[0,0,1]])
 return -C if inv else C

def kM(M):return tuple(M)
def pointops(g):
 seen=set();out=[]
 for o in g['operations']:
  R=matrix(o['label'],int(g['id'].split('.')[0])>=65)
  key=(o['s'],kM(R))
  if key not in seen:out.append((o['s'],R,o['label']));seen.add(key)
 return out

def point_closure(g):
 ops=pointops(g);keys={(s,kM(R)) for s,R,_ in ops}
 for s,R,_ in ops:
  for t,U,_ in ops:
   if(s*t,kM(S.simplify(R*U)))not in keys:return False
 return True

def fracops(g):
 B=HEX if int(g['id'].split('.')[0])>=65 else I;inv=B.inv();out=[]
 for o in g['operations']:
  R=S.simplify(inv*matrix(o['label'],B==HEX)*B)
  if any(not x.is_integer for x in R):raise ValueError((g['id'],o['label'],R))
  t=S.Matrix([S.Rational(v) for v in o['translation'].split(',')])
  out.append((o['s'],R,t))
 return out

def full_closure(g):
 ops=fracops(g)
 def key(s,R,t):return(s,kM(R),tuple(v%1 for v in t))
 keys={key(s,R,t)for s,R,t in ops}
 return all(key(s*q,R*Q,R*u+t)in keys for s,R,t in ops for q,Q,u in ops)

def corrected_catalog():
 catalog=json.loads((ROOT/'source_catalog_448.json').read_text())
 # Explicitly recorded erratum: raw op 04 contradicts both closure and +1 m in the symbol.
 for g in catalog:
  if g['id']=='31.5.192':g['operations'][3]['s']=1
  if g['id']=='39.5.260':g['operations'][7]['translation']='0,1/2,0'
  if g['id']=='77.1.505':g['operations'][8]['s']=1
 return catalog

if __name__=='__main__':
 cat=corrected_catalog()
 for g in cat:
  if not point_closure(g):print('POINT FAIL',g['id'],g['symbol_raw'])
 print('Target full-affine checks:')
 for g in cat:
  if g['table']==7 and not full_closure(g):print('FULL FAIL',g['id'])
