from symmetry_core import *
from identify_mlg import spg_key,point_invariant,arrays
from collections import Counter

def canonical(v):
 v=S.Matrix(v)
 j=next(i for i,x in enumerate(v)if x!=0)
 return S.simplify(v/v[j])
def integer_tuple(v):
 v=canonical(v)
 if any(not x.is_Rational for x in v):raise ValueError(v)
 den=S.ilcm(*[x.q for x in v]);vals=[int(x*den)for x in v]
 div=math.gcd(*vals)
 return tuple(x//div for x in vals)
def direction_set(g):
 ops=pointops(g);axes={};planes={}
 for _,R,_ in ops:
  A=R.det()*R
  if A==I:continue
  for value,mul,vs in A.eigenvects():
   if value not in [S.Integer(1),S.Integer(-1)]:continue
   if len(vs)==1:axes[kM(canonical(vs[0]))]=canonical(vs[0])
   if len(vs)==2:
    v=canonical(vs[0].cross(vs[1]));planes[kM(v)]=v
 for u,v in itertools.combinations(list(planes.values()),2):
  w=u.cross(v)
  if w!=S.zeros(3,1):axes[kM(canonical(w))]=canonical(w)
 B=HEX if int(g['id'].split('.')[0])>=65 else I
 out=[]
 for d in axes.values():out.append({'kind':'AX','indices':integer_tuple(B.inv()*d),'sample':d})
 for d in planes.values():
  n=S.Matrix([1,2,0]) if d[0]==d[1]==0 else S.Matrix([-d[1],d[0],2])
  out.append({'kind':'PL','indices':integer_tuple(B.T*d),'sample':n})
 axorder=[(1,0,0),(0,1,0),(1,1,0),(1,-1,0),(1,2,0),(2,1,0),(0,0,1)]
 plorder=[(0,0,1),(0,1,0),(1,0,0),(1,1,0),(1,-1,0),(2,-1,0),(1,-2,0)]
 def sortkey(d):
  ls=axorder if d['kind']=='AX' else plorder
  return (0 if d['kind']=='AX' else 1,ls.index(d['indices'])if d['indices']in ls else 99,str(d['indices']))
 out.sort(key=sortkey)
 out.append({'kind':'GEN','indices':None,'sample':S.Matrix([1,2,3])})
 return out

def active_ops(g,n):
 act=[]
 for s,R,label in pointops(g):
  an=R.det()*R*n
  e=1 if S.simplify(an-n)==S.zeros(3,1) else -1 if S.simplify(an+n)==S.zeros(3,1) else 0
  if e:act.append((s*e,R,label))
 return act

@lru_cache(None)
def solve_response(key):
 equations=[]
 for q,flat in key:
  R=S.Matrix(3,3,flat);D=q*R[:2,:2]
  swap=R[2,2]==-1
  for layer in [0,1]:
   target=1-layer if swap else layer
   for a in range(2):
    eq=S.zeros(1,4);eq[0,2*target+a]=1
    for b in range(2):eq[0,2*layer+b]-=D[a,b]
    equations.append(eq)
 M=S.Matrix.vstack(*equations)
 ns=M.nullspace();N=S.Matrix.hstack(*ns)if ns else S.zeros(4,0)
 flags=[]
 for a in range(2):
  top=N[a,:];bottom=N[a+2,:]
  if top==S.zeros(1,N.cols)and bottom==S.zeros(1,N.cols):flags.append('0')
  elif top==bottom:flags.append('+')
  elif top==-bottom:flags.append('-')
  else:flags.append('v')
 # Flag any constraints mixing A and B, beyond the per-component layer flags.
 simple=[]
 for a,f in enumerate(flags):
  if f=='0':
   for off in [0,2]:
    eq=S.zeros(1,4);eq[0,a+off]=1;simple.append(eq)
  elif f in ['+','-']:
   eq=S.zeros(1,4);eq[0,a]=1;eq[0,a+2]=-1 if f=='+' else 1;simple.append(eq)
 simple_rank=S.Matrix.vstack(*simple).rank()if simple else 0
 coupled=M.rank()>simple_rank
 return flags,N,coupled,M.rank()

def analyze():
 cat=corrected_catalog();lookup=json.loads((ROOT/'mlg_lookup_index.json').read_text())
 ix={(e['uni'],tuple(tuple(x)for x in e['invariant'])):e['ids']for e in lookup['entries']}
 targets=[g for g in cat if g['table']==7];results=[];amb=[]
 for i,g in enumerate(targets,1):
  print('Computing',i,g['id'],flush=True)
  entry=copy.deepcopy(g);entry['ordinal']=i;entry['branches']=[]
  for j,d in enumerate(direction_set(g),1):
   act=active_ops(g,d['sample']);key=tuple((q,kM(R))for q,R,_ in act)
   flags,N,coupled,rank=solve_response(key)
   qs={kM(R):q for q,R,_ in act}
   sub=copy.deepcopy(g);sub['operations']=[]
   for o in g['operations']:
    R=matrix(o['label'],int(g['id'].split('.')[0])>=65)
    if kM(R)in qs:
     oo=copy.deepcopy(o);oo['s']=qs[kM(R)];sub['operations'].append(oo)
   identkey=spg_key(sub);ids=ix.get(identkey,[])
   b={'row_id':f'{i:02d}.{j:02d}','kind':d['kind'],'indices':d['indices'],'sample_cartesian':[str(x)for x in d['sample']],
      'operations':[{'q':q,'label':label,'matrix_cartesian':[[str(x)for x in R.row(k)]for k in range(3)]}for q,R,label in act],
      'mlg_candidates':ids,'mlg_id':ids[0]if len(ids)==1 else None,'spglib_uni':identkey[0]if identkey else None,
      'flags':flags,'coupled':bool(coupled),'dimension':N.cols,'basis':[[str(x)for x in N.row(k)]for k in range(4)]}
   if len(ids)!=1:amb.append((g['id'],b['row_id'],d['kind'],d['indices'],ids))
   entry['branches'].append(b)
  results.append(entry)
 (ROOT/'calculation_results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
 print('RESULT',len(results),'groups',sum(len(g['branches'])for g in results),'branches')
 print('AMBIGUOUS',amb)
 print('FLAG COUNTS',Counter(tuple(b['flags'])for g in results for b in g['branches']))
 print('COUPLED',sum(b['coupled']for g in results for b in g['branches']))
if __name__=='__main__':analyze()
