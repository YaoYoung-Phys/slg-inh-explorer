"""Identify layer groups using the source catalog and 3D embeddings, preserving z."""
from symmetry_core import *
import spglib
from collections import defaultdict

def arrays(g):
 ops=fracops(g)
 return np.array([np.array(R).astype(int) for s,R,t in ops],dtype=int),np.array([np.array(t).astype(float).ravel() for s,R,t in ops]),np.array([s==-1 for s,R,t in ops],dtype=int)
def point_invariant(rot,rev):
 return tuple(sorted({(int(q),int(round(np.linalg.det(R))),int(np.trace(R)),int(R[2,2])) for R,q in zip(rot,rev)}))

def spg_key(g):
 r,t,q=arrays(g)
 B=np.array(HEX if int(g['id'].split('.')[0])>=65 else I).astype(float)
 B[:,2]*=4
 typ=spglib.get_magnetic_spacegroup_type_from_symmetry(r,t,q,B.T)
 return None if typ is None else (typ.uni_number,point_invariant(r,q))

def make_index():
 cat=corrected_catalog();bykey=defaultdict(list);failed=[]
 for g in cat:
  key=spg_key(g)
  if key is None:failed.append(g['id'])
  else:bykey[key].append(g['id'])
 serial=[{'uni':k[0],'invariant':k[1],'ids':v}for k,v in bykey.items()]
 (ROOT/'mlg_lookup_index.json').write_text(json.dumps({'entries':serial,'failed':failed},indent=2))
 print('lookup indexed',sum(len(v)for v in bykey.values()),'failures',failed)
 print('ambiguous',[(k[0],v)for k,v in bykey.items()if len(v)>1])
 return bykey

if __name__=='__main__':make_index()
