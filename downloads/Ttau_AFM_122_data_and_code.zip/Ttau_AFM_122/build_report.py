from format_symbols import *
import csv
results=json.loads((ROOT/'calculation_results.json').read_text())
cat={g['id']:g for g in corrected_catalog()}
notes={108:'S1',120:'S2'}
header=r'''\documentclass[10pt]{article}
\usepackage[paperwidth=420mm,paperheight=297mm,margin=11mm]{geometry}
\usepackage[T1]{fontenc}
\usepackage{lmodern,amsmath,amssymb,array,multirow,booktabs,longtable,graphicx}
\usepackage[hidelinks,pdftitle={122 T-tau AFM cSLGs: Neel directions, SOC MLGs and hidden INH}]{hyperref}
\pagestyle{plain}
\setlength{\footskip}{18pt}
\setlength{\parindent}{0pt}
\setlength{\parskip}{4pt}
\setlength{\LTpre}{0pt}\setlength{\LTpost}{0pt}
\newcommand{\fitops}[1]{\begingroup\setbox0=\hbox{\fontsize{8}{9}\selectfont$#1$}\ifdim\wd0>210mm\typeout{WIDE-OPS: \the\wd0}\resizebox{210mm}{!}{\box0}\else\box0\fi\endgroup}
\newcommand{\rowstrut}{}
\begin{document}
\begin{minipage}{300mm}
{\LARGE\bfseries 122 $T\tau$ AFM collinear spin layer groups}\par
{\Large N\'eel directions, SOC magnetic layer groups and layer-resolved intrinsic nonlinear Hall constraints}\par
\vspace{4mm}
\textbf{Coverage.} All 122 entries of Table S4, in the original order, expanded into \textbf{738 direction branches}: 2 groups have 1 branch, 38 have 3, 70 have 7, and 12 have 11. Directions related by a parent symmetry are retained in the fixed source coordinate setting so that the displayed tensor indices stay meaningful. These 738 rows are direction strata, not 738 distinct MLG types.

\textbf{Source.} J.-X. Du, S. Zeng and Y.-J. Zhao, \textit{Stacking theory for bilayer two-dimensional magnets}, Phys. Rev. B \textbf{113}, 214455 (2026), DOI: \href{https://doi.org/10.1103/g471-xrkl}{10.1103/g471-xrkl}; Supplemental Material, Table S4, pp.~34--63. The source supplies the cSLGs and operations. The N\'eel-direction branches, SOC MLGs and response constraints in this report are calculated results.

\textbf{Direction notation.} $\mathrm{AX}_{[uvw]}$ denotes a special axis; $\mathrm{PL}_{(hkl)}$ denotes a direction in a special plane excluding all axes lying in that plane; $\mathrm{GEN}$ denotes a direction outside every listed axis and plane. Only symmetry-distinct stabilizer strata of a given group are introduced; for example, groups $1.3.3$ and $2.4.7$ have a single $\mathrm{GEN}$ row covering all directions.

\textbf{Coordinates and numbering.} $z$ is normal to the physical layers; Cartesian $x,y$ follow the rectangular or tetragonal source family-cell axes $\mathbf a,\mathbf b$. Direction indices refer to that source cell, not to an enlarged magnetic cell. Table S4 uses \textbf{OG notation}; the complete lattice subscripts, symbols and three-part identifiers are retained. The 122 nonrelativistic $T\tau$ AFM groups are distinct from the 66 groups called type-IV two-dimensional magnets in Table S6.

\textbf{Operation columns.} Translation parts are omitted and repeated point operations are merged. All distinct nontrivial-part SLG point operations are shown on separate lines; the common spin-only factor is implicit. Every MLG row explicitly lists its point operations on one line. Full MLG symbols and numbers are nevertheless identified from the full affine operations in the source, then verified by a basis/origin change preserving the layer normal. MLG symbols use the reference OG settings; the explicitly listed operations and tensor indices remain in the source coordinate setting. An affine witness for every row is included in the data package. Omitting translations from the displayed columns does not redefine these group identifiers. In these projected columns, $\{-1\Vert E\}$ and $\mathcal T$ originate from anti-translations; they do not assert bare time-reversal symmetry of the full spatial group. The magnetic translation lattice is retained in every identification and affine check.

\textbf{Tensor convention.} Set $A^\ell=\chi^\ell_{xyy}$ and $B^\ell=\chi^\ell_{yxx}$ for $\ell=t,b$, with $\chi_{abc}=-\chi_{bac}$ and in-plane indices. Then $\chi_{xyx}=-B$, $\chi_{yxy}=-A$, and all other in-plane entries vanish. The two-component vector $\mathbf v^\ell=(A^\ell,B^\ell)$ transforms as $\mathbf v^{g\ell}=q_g R_\parallel\mathbf v^\ell$. This statement is specific to the $\mathcal T$-odd intrinsic Hall part.

\begin{tabular}{cll}\toprule
Mark & Constraint on the displayed component & Meaning\\\midrule
$+$ & $\chi^t=\chi^b$, allowed & Equal layer contributions\\
$-$ & $\chi^t=-\chi^b$, allowed & Hidden, layer compensated\\
$0$ & $\chi^t=\chi^b=0$ & Forbidden in each layer\\
$v$ & No fixed proportional relation between the same component in the two layers & See coupled constraints when starred\\\bottomrule
\end{tabular}

\textbf{Uniform result.} Every listed SOC subgroup contains $\{\mathcal T\mid\boldsymbol\tau\}$ with $\tau_z=0$. This operation preserves each physical layer and reverses the $\mathcal T$-odd, spatially averaged intrinsic Hall tensor. Consequently $\chi_{xyy}^{t}=\chi_{xyy}^{b}=\chi_{yxx}^{t}=\chi_{yxx}^{b}=0$ for all \textbf{738 branches}. The two response columns therefore contain $0$ throughout. These are layer-resolved zeros; no locally finite layer contribution survives to form a hidden interlayer pair. Appendix A gives the derivation and magnetic-cell conventions.

\textbf{Assumptions and calculation.} Fixed structure and collinear order; two physical layers at opposite sides of $z=0$. The SOC subgroup satisfies $q_g\det(R_g)R_g\hat{\mathbf n}=s_g\hat{\mathbf n}$, with $q_g=+1$ for $g$ and $q_g=-1$ for $g\mathcal T$. Operations with $R_{zz}=-1$ exchange the two layers. Branches are constructed from all real $\pm1$ eigenspaces and their intersections. These are symmetry-allowed constrained orientations, not predictions of magnetic easy axes or stability.

\textbf{Source audit (original entries retained in the raw data).} Two isolated translation entries violate multiplication by the explicitly listed anti-translation $(1,0,0)$:
\begin{itemize}\setlength\itemsep{0pt}
\item[S1.] $50.4.361$ (p.~56), operation 06: use $(1,0,0)$ for $\{-1\Vert C_{2z}\}$, replacing the printed $(1/2,0,0)$.
\item[S2.] $61.11.432$ (p.~61), operation 25: use $(1,0,0)$ for $\{-1\Vert\mathcal P\}$, replacing the printed $(0,0,0)$.
\end{itemize}
Both repairs follow directly by multiplying operation 05 or 17 (the anti-translation) by operation 02 or 09, respectively. All 122 corrected lists close in their magnetic translation lattices and agree with the printed SLG symbols. These are consistency repairs, not author-issued errata; they do not change the projected operations or the universal zero-response result.

\textbf{Validation.} All 738 MLG assignments are checked against complete affine operations. Each allowed response space is independently checked using the full third-rank Hall tensor, and direction coverage is sampled on every axis and plane as well as generic orientations.
\end{minipage}
\clearpage
{\Large\bfseries Complete table, in Table S4 order}\par
\small First three columns are merged across all direction branches of one cSLG. S1--S2 refer to the source audit. All response entries are zero by the layer-preserving anti-translation constraint.\par
\vspace{3mm}
\fontsize{8.5}{10}\selectfont
\setlength{\tabcolsep}{1.1mm}
\newcolumntype{C}[1]{w{c}{#1}}
\newcolumntype{L}[1]{w{l}{#1}}
\setbox\strutbox\hbox{\vrule height7pt depth3pt width0pt}
'''
parts=[header]
columns=r'@{}C{28mm} C{24mm} C{40mm} C{24mm} C{28mm} L{210mm} C{11mm} C{11mm}@{}'
heading=r'\shortstack{cSLG label\\and symbol} & \shortstack{Nonrelativistic\\class} & Operation in SLG & \shortstack{N\'eel\\direction} & \shortstack{SOC MLG (OG)\\symbol and number} & Operation in MLG & $\chi_{xyy}^{t,b}$ & $\chi_{yxx}^{t,b}$ \\'
used=0
page_number=0
for g in results:
 n=len(g['branches']);hexa=int(g['id'].split('.')[0])>=65;no=g['ordinal']
 spinops=pointops(cat[g['id']])
 rowheight=max(23,(14*len(spinops)+10)/n,60/n)
 groupheight=n*rowheight+0.3*(n-1)+7
 if used==0 or used+groupheight>680:
  if used:parts.append(r'\clearpage'+ '\n')
  page_number+=1
  parts.append(r'\noindent\begin{tabular}{'+columns+'}'+r'\toprule'+heading+r'\midrule\end{tabular}\par\vspace{-4pt}'+'\n')
  used=0
 parts.append(r'\noindent\begin{minipage}{\textwidth}\renewcommand{\arraystretch}{'+str(rowheight/10)+r'}\setlength{\aboverulesep}{0pt}\setlength{\belowrulesep}{0pt}\begin{tabular}{'+columns+'}'+'\n')
 used+=groupheight
 scell=r'\begin{gathered}'+r'\\[1pt]'.join(r'\{'+str(s)+r'\Vert '+op_symbol(label,hexa)+r'\}'for s,R,label in spinops)+r'\end{gathered}'
 audit=' ('+notes[no]+')'if no in notes else ''
 first=r'\multirow{'+str(n)+r'}{28mm}{\centering\shortstack{\textbf{'+f'{no:02d}'+r'}'+audit+r'\\$'+g['id']+r'$\\[2pt]$'+hm(cat[g['id']],True)+r'$\\[2pt]{\scriptsize SI p.~'+str(g['label_page'])+r'}}}'
 second=r'\multirow{'+str(n)+r'}{24mm}{\centering $T\tau$ AFM}'
 third=r'\multirow{'+str(n)+r'}{40mm}{\centering\fontsize{8}{9}\selectfont$'+scell+'$}'
 for j,b in enumerate(g['branches']):
  d=direction(b)+(r'^{*}'if b['coupled']else '')
  m=cat[b['mlg_id']];mcell=r'\shortstack{$'+hm(m)+r'$\\$'+b['mlg_id']+'$}'
  fields=[first if j==0 else '',second if j==0 else '',third if j==0 else '',r'\rowstrut $'+d+'$',mcell,r'\fitops{'+mlg_ops(b,hexa)+'}','$'+b['flags'][0]+'$','$'+b['flags'][1]+'$']
  parts.append(' & '.join(fields)+r'\\'+'\n')
  if j<n-1:parts.append(r'\cmidrule(l){4-8}'+'\n')
 parts.append(r'\bottomrule\end{tabular}\end{minipage}\par\vspace{-4pt}'+'\n')
parts.append(r'''\clearpage
{\Large\bfseries Appendix A. Why every layer response vanishes}\par
\normalsize
The anti-translation $g_\tau=\{\mathcal T\mid\boldsymbol\tau\}$ has spatial point part $R=E$, time-reversal parity $q=-1$ and $\tau_z=0$. It preserves the identity of each physical layer. For a homogeneous electric field and the response averaged over the full magnetic in-plane cell,
\[
\chi_{abc}^{\ell}\xrightarrow{g_\tau}-\chi_{abc}^{\ell},\qquad
\ell=t,b.
\]
Neumann invariance therefore imposes $\chi_{abc}^{\ell}=-\chi_{abc}^{\ell}$ and hence $\chi_{abc}^{\ell}=0$ for the time-reversal-odd intrinsic Hall part. In the four-component representation used throughout the tables,
\[
(A^t,B^t,A^b,B^b)=(0,0,0,0),\qquad \dim\mathcal V_{\mathrm{allowed}}=0.
\]
The constraint holds for every N\'eel direction because the spatial point part of the spin-reversing translation is the identity. Rotating the common spin axis does not remove $g_\tau$ from the SOC subgroup. The conclusion concerns the physical-layer projection used in the table; a projection onto a smaller sublattice exchanged by $\boldsymbol\tau$ need not obey the same local-zero statement.

\vspace{5mm}
{\large\bfseries Magnetic translation lattices in the source OG coordinates}\par
The columns below span the unitary translation lattice $L_+$ in the source family-cell basis. Listed anti-translations are representatives modulo $L_+$. The pair $q,R$ alone is insufficient to identify the full magnetic layer group.
\begin{center}
\begin{tabular}{c c c}\toprule
OG lattice prefix & Basis of $L_+$ & Anti-translation representative\\\midrule
$p_{2a}$ & $(2\mathbf a,\mathbf b)$ & $\mathbf a$\\[3pt]
$p_{2b}$ & $(\mathbf a,2\mathbf b)$ & $\mathbf b$\\[3pt]
$p_c$ & $(\mathbf a+\mathbf b,-\mathbf a+\mathbf b)$ & $\mathbf b$\\[3pt]
$p_p$ & $(\mathbf a+\mathbf b,-\mathbf a+\mathbf b)$ & $\mathbf a$\\[3pt]
$c_p$ & $(\mathbf a,\mathbf b)$ & $(\mathbf a+\mathbf b)/2$\\\bottomrule
\end{tabular}
\end{center}
If $P$ contains these basis vectors as columns, affine operations are normalized as $R_m=P^{-1}RP$ and $t_m=P^{-1}t$. Translations are reduced modulo integer vectors only after this transformation. This is essential: reducing an anti-translation $(1,0,0)$ modulo the source family cell would incorrectly turn it into a pure time reversal.

Every reported MLG has an explicit affine witness preserving the layer normal. The data package gives the source operations, normalized magnetic-cell basis, SOC subgroup operations, full allowed tensor space and the basis/origin transformation. Group labels and MLG primes are in the reference OG setting, while the Operation in MLG column remains in the source Cartesian setting.
\end{document}''')
(ROOT/'Ttau_AFM_122_cSLG_Neel_MLG_INH.tex').write_text(''.join(parts))
# Plain structured deliverable includes all constraints, complete affine witnesses and source operations.
for g in results:
 g['symbol_latex']=hm(cat[g['id']],True)
 g['magnetic_translation_basis']=[[str(x)for x in row]for row in magnetic_basis(g).tolist()]
 for b in g['branches']:
  sub=soc_subgroup(g,S.Matrix([S.sympify(x)for x in b['sample_cartesian']]))
  b['full_soc_operations_source']=sub['operations']
  b['mlg_symbol_latex']=hm(cat[b['mlg_id']]);b['direction_latex']=direction(b);b['complete_constraint_latex']=basis_tex(b)
(ROOT/'Ttau_AFM_122_results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
print('Generated',len(results),'group tables and',sum(b['coupled']for g in results for b in g['branches']),'coupled rows')
