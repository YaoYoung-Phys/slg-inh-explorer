"""Independent checks of closure, coverage, Hall-tensor covariance and the worked example."""
import json,math,itertools
from pathlib import Path
import numpy as np
ROOT=Path(__file__).parent
rows=json.loads((ROOT/'TypeIV_66_results.json').read_text())
import sympy as S
from symmetry_core import corrected_catalog,pointops,fracops,I,HEX

def arr(m):return np.array(m).astype(float)
def key(M):return tuple(np.round(M,9).ravel())
def evalbasis(b):return np.array([[float(S.sympify(x))for x in r]for r in b['basis']])if b['dimension']else np.zeros((4,0))
checks={'groups':len(rows),'branches':sum(len(g['branches'])for g in rows),'source_closure':0,'mlg_point_closure':0,'full_tensor_covariance':0,'coverage_samples':0,'affine_witnesses':0}
cat={g['id']:g for g in corrected_catalog()}
rng=np.random.default_rng(66314)
for g in rows:
 src=cat[g['id']];sp=[(s,arr(R))for s,R,_ in pointops(src)];sk={(s,key(R))for s,R in sp}
 assert all((s*t,key(R@Q))in sk for s,R in sp for t,Q in sp)
 # Full affine closure with exact half translations represented numerically.
 af=[(s,arr(R),arr(t).ravel())for s,R,t in fracops(src)]
 fk={(s,key(R),key(t%1))for s,R,t in af}
 for s,R,t in af:
  for q,Q,u in af:assert(s*q,key(R@Q),key((R@u+t)%1))in fk
 checks['source_closure']+=1
 branchkeys=set()
 for b in g['branches']:
  ops=[(o['q'],arr(S.Matrix(o['matrix_cartesian'])))for o in b['operations']]
  ks={(q,key(R))for q,R in ops};branchkeys.add(frozenset(ks))
  assert all((q*p,key(R@Q))in ks for q,R in ops for p,Q in ops)
  checks['mlg_point_closure']+=1
  N=evalbasis(b)
  assert np.linalg.matrix_rank(N) == N.shape[1] if N.shape[1] else True
  # Verify with a direct third-rank tensor, independently of the reduced-vector rule.
  for v in N.T:
   T=np.zeros((2,2,2,2))
   for ell in [0,1]:
    A,B=v[2*ell:2*ell+2]
    T[ell,0,1,1]=A;T[ell,1,0,0]=B;T[ell,0,1,0]=-B;T[ell,1,0,1]=-A
   for q,R in ops:
    r=R[:2,:2];swap=R[2,2]<0
    for ell in [0,1]:
     transformed=q*np.einsum('ai,bj,ck,ijk->abc',r,r,r,T[ell])
     assert np.allclose(transformed,T[1-ell if swap else ell],atol=1e-10)
  checks['full_tensor_covariance']+=1
  assert b['mlg_id'] and b['affine_witness']
  checks['affine_witnesses']+=1
 # Cover random generic directions plus random points in each special plane and axes.
 samples=list(rng.normal(size=(12,3)))
 Bmat=arr(HEX if int(g['id'].split('.')[0])>=65 else I)
 for b in g['branches']:
  if b['kind']=='AX':samples.append(Bmat@np.array(b['indices']))
  if b['kind']=='PL':
   normal=np.linalg.inv(Bmat).T@np.array(b['indices']);normal/=np.linalg.norm(normal)
   for _ in range(4):
    v=rng.normal(size=3);samples.append(v-normal*np.dot(normal,v))
 for n in samples:
  active=[]
  for s,R in sp:
   u=np.linalg.det(R)*R@n
   if np.allclose(u,n,atol=1e-9):active.append((s,key(R)))
   elif np.allclose(u,-n,atol=1e-9):active.append((-s,key(R)))
  assert frozenset(active)in branchkeys,(g['id'],n)
  checks['coverage_samples']+=1
ex=next(g for g in rows if g['id']=='36.3.223')
assert [b['flags']for b in ex['branches']]==[['+','0'],['0','+'],['0','-'],['+','+'],['+','-'],['0','v'],['v','v']]
assert [b['mlg_id']for b in ex['branches']]==['36.5.225','36.1.221','36.4.224','5.1.17','10.3.47','13.1.61','1.1.1']
checks['worked_example']='passed'
checks['coupled_branches']=sum(b['coupled']for g in rows for b in g['branches'])
checks['all_passed']=True
(ROOT/'validation_summary.json').write_text(json.dumps(checks,indent=2))
print(json.dumps(checks,indent=2))
