"""Verify each reported MLG against full source operations by a z-preserving affine map."""
from symmetry_core import *
from calculate import active_ops
from functools import lru_cache

def keyR(R):return tuple(np.rint(R).astype(int).ravel())
def normalized_ops(g):
 ops=fracops(g)
 centered=any(R==I and s==1 and tuple(t)==(S.Rational(1,2),S.Rational(1,2),0)for s,R,t in ops)
 P=np.array([[.5,-.5,0],[.5,.5,0],[0,0,1]])if centered else np.eye(3)
 Pi=np.linalg.inv(P);d={}
 for q,R,t in ops:
  rr=Pi@np.array(R).astype(float)@P;tt=(Pi@np.array(t).astype(float).ravel())%1
  d[(q,keyR(rr))]=tt
 return P,[(q,np.array(k).reshape(3,3),t)for(q,k),t in d.items()]

def umat_range(limit):
 us=[]
 for a,b,c,d in itertools.product(range(-limit,limit+1),repeat=4):
  if abs(a*d-b*c)==1:
   U=np.eye(3);U[:2,:2]=[[a,b],[c,d]];us.append(U)
 us.sort(key=lambda U:(np.sum(np.abs(U-np.eye(3))),tuple(U.ravel())))
 return us
US=umat_range(2)
ORIGINS=np.array([(a/4,b/4,0)for a,b in itertools.product(range(4),repeat=2)])

def witness(source,target):
 Ps,ss=normalized_ops(source);Pt,ts=normalized_ops(target)
 targetR={(q,keyR(R))for q,R,t in ts}
 td={(q,keyR(R)):t for q,R,t in ts}
 if len(ss)!=len(ts):return None
 for U in US:
  Ui=np.linalg.inv(U)
  rs=[Ui@R@U for q,R,t in ss]
  if any(np.max(np.abs(R-np.rint(R)))>1e-7 for R in rs):continue
  if {(q,keyR(R))for(q,_,_),R in zip(ss,rs)}!=targetR:continue
  for o in ORIGINS:
   good=True
   for(q,R,t),Rt in zip(ss,rs):
    dt=Ui@(t+(R-np.eye(3))@o)-td[(q,keyR(Rt))]
    if np.max(np.abs(dt-np.rint(dt)))>1e-7:good=False;break
   if good:
    return {'conventional_basis_map':(Ps@U@np.linalg.inv(Pt)).tolist(),'origin_in_source':(Ps@o).tolist(),
      'equation':'x_source = conventional_basis_map @ x_standard_MLG + origin_in_source'}
 return None

def run():
 cat={g['id']:g for g in corrected_catalog()};results=json.loads((ROOT/'calculation_results.json').read_text())
 failed=[];cache={};count=0
 for g in results:
  source=cat[g['id']]
  for b in g['branches']:
   n=S.Matrix([S.sympify(x)for x in b['sample_cartesian']]);act=active_ops(source,n)
   qs={kM(R):q for q,R,_ in act};sub=copy.deepcopy(source);sub['operations']=[]
   for op in source['operations']:
    R=matrix(op['label'],int(g['id'].split('.')[0])>=65)
    if kM(R)in qs:
     oo=copy.deepcopy(op);oo['s']=qs[kM(R)];sub['operations'].append(oo)
   successes=[]
   for cand in b['mlg_candidates']:
    ck=(json.dumps(sub['operations'],sort_keys=True),cand)
    if ck not in cache:cache[ck]=witness(sub,cat[cand])
    if cache[ck]is not None:successes.append((cand,cache[ck]))
   if len(successes)==1:
    b['mlg_id'],b['affine_witness']=successes[0];count+=1
   else:failed.append((b['row_id'],g['id'],b['kind'],b['indices'],b['mlg_candidates'],[x[0]for x in successes]))
  print('Verified group',g['ordinal'],flush=True)
 (ROOT/'calculation_results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
 print('AFFINE VERIFIED',count,'FAILED',failed)
if __name__=='__main__':run()
