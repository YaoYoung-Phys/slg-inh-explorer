from format_symbols import *
import csv
results=json.loads((ROOT/'calculation_results.json').read_text())
cat={g['id']:g for g in corrected_catalog()}
notes={}
header=r'''\documentclass[10pt]{article}
\usepackage[paperwidth=420mm,paperheight=297mm,margin=11mm]{geometry}
\usepackage[T1]{fontenc}
\usepackage{lmodern,amsmath,amssymb,array,multirow,booktabs,longtable,graphicx}
\usepackage[hidelinks,pdftitle={92 AM cSLGs: Neel directions, SOC MLGs and hidden INH}]{hyperref}
\pagestyle{plain}
\setlength{\footskip}{18pt}
\setlength{\parindent}{0pt}
\setlength{\parskip}{4pt}
\setlength{\LTpre}{0pt}\setlength{\LTpost}{0pt}
\newcommand{\fitops}[1]{\begingroup\setbox0=\hbox{\fontsize{8}{9}\selectfont$#1$}\ifdim\wd0>210mm\typeout{WIDE-OPS: \the\wd0}\resizebox{210mm}{!}{\box0}\else\box0\fi\endgroup}
\newcommand{\rowstrut}{}
\begin{document}
\begin{minipage}{300mm}
{\LARGE\bfseries 92 AM collinear spin layer groups}\par
{\Large N\'eel directions, SOC magnetic layer groups and layer-resolved intrinsic nonlinear Hall constraints}\par
\vspace{4mm}
\textbf{Coverage.} All 92 entries of Table S7, in the original order, expanded into \textbf{774 direction branches}: 15 groups have 3 branches, 30 have 7, 6 have 8, 36 have 11, and 5 have 15. Directions related by a parent symmetry are retained in the fixed source coordinate setting so that the displayed tensor indices stay meaningful. These 774 rows are direction strata, not 774 distinct MLG types.

\textbf{Source.} J.-X. Du, S. Zeng and Y.-J. Zhao, \textit{Stacking theory for bilayer two-dimensional magnets}, Phys. Rev. B \textbf{113}, 214455 (2026), DOI: \href{https://doi.org/10.1103/g471-xrkl}{10.1103/g471-xrkl}; Supplemental Material, Table S7, pp.~96--113. The source supplies the cSLGs and operations. The N\'eel-direction branches, SOC MLGs and response constraints in this report are calculated results.

\textbf{Direction notation.} $\mathrm{AX}_{[uvw]}$ denotes a special axis; $\mathrm{PL}_{(hkl)}$ denotes a direction in a special plane excluding all axes lying in that plane; $\mathrm{GEN}$ denotes a direction outside every listed axis and plane. Only symmetry-distinct stabilizer strata of a given group are introduced; for example, the first group needs only $\mathrm{AX}_{[100]}$, $\mathrm{PL}_{(100)}$ and $\mathrm{GEN}$.

\textbf{Coordinates.} Tensor components are Cartesian, with $z$ normal to the layer. For rectangular and tetragonal groups, $x\parallel\mathbf a$, $y\parallel\mathbf b$. For hexagonal groups, $\mathbf a=(1,0,0)$ and $\mathbf b=(-1/2,\sqrt3/2,0)$, while Cartesian $y\parallel\hat z\times\mathbf a$. Miller indices refer to these crystallographic bases. Thus $[010]$ is not the Cartesian $y$ direction in the hexagonal setting. Hexagonal in-plane operations are displayed with explicit crystallographic directions; $M_{[uvw]}$ has its Cartesian normal along $[uvw]$. The source triplets $\{x,y,xy\}$ and $\{1,2,3\}$ correspond as sets to $\{[100],[010],[110]\}$ and $\{[1\bar10],[120],[210]\}$. No individual identification of the source's numbered subscripts is needed.

\textbf{Operation columns.} Translation parts are omitted and repeated point operations are merged. All distinct nontrivial-part SLG point operations are shown on separate lines; the common spin-only factor is implicit. Every MLG row explicitly lists its point operations on one line. Full MLG symbols and numbers are nevertheless identified from the full affine operations in the source, then verified by a basis/origin change preserving the layer normal. MLG symbols use their standard settings; the explicitly listed operations and tensor indices remain in the source coordinate setting. An affine witness for every row is included in the data package. Omitting translations from the displayed columns does not redefine these group identifiers.

\textbf{Tensor convention.} Set $A^\ell=\chi^\ell_{xyy}$ and $B^\ell=\chi^\ell_{yxx}$ for $\ell=t,b$, with $\chi_{abc}=-\chi_{bac}$ and in-plane indices. Then $\chi_{xyx}=-B$, $\chi_{yxy}=-A$, and all other in-plane entries vanish. The two-component vector $\mathbf v^\ell=(A^\ell,B^\ell)$ transforms as $\mathbf v^{g\ell}=q_g R_\parallel\mathbf v^\ell$. This statement is specific to the $\mathcal T$-odd intrinsic Hall part.

\begin{tabular}{cll}\toprule
Mark & Constraint on the displayed component & Meaning\\\midrule
$+$ & $\chi^t=\chi^b$, allowed & Equal layer contributions\\
$-$ & $\chi^t=-\chi^b$, allowed & Hidden, layer compensated\\
$0$ & $\chi^t=\chi^b=0$ & Forbidden in each layer\\
$v$ & No fixed proportional relation between the same component in the two layers & See coupled constraints when starred\\\bottomrule
\end{tabular}

A star on a direction indicates additional relations between $A$ and $B$, listed completely in Appendix A (208 branches). In these rows, $v$ must not be read as absence of all symmetry relations: cross-component relations may remain. All allowed values can accidentally vanish microscopically.

\textbf{Assumptions and calculation.} Fixed structure and collinear order; two physical layers at opposite sides of $z=0$. The SOC subgroup satisfies $q_g\det(R_g)R_g\hat{\mathbf n}=s_g\hat{\mathbf n}$, with $q_g=+1$ for $g$ and $q_g=-1$ for $g\mathcal T$. Operations with $R_{zz}=-1$ exchange the two layers. Branches are constructed from all real $\pm1$ eigenspaces and their intersections. These are symmetry-allowed constrained orientations, not predictions of magnetic easy axes or stability.

\textbf{Source audit.} All 92 target operation lists close as printed, and their spin labels agree with the printed cSLG symbols; no target operation was modified. The reference catalog used for MLG identification retains three explicitly documented consistency repairs: $31.5.192$, operation 04, $s_{M_x}=+1$; $39.5.260$, operation 08, translation $(0,1/2,0)$; and FM reference $77.1.505$, operation 09, $s_{M_y}=+1$. These are consistency choices derived from group closure, not an author-issued erratum. Original source strings are retained in the data package.

\textbf{Validation.} All 774 MLG assignments are checked against complete affine operations. Each allowed response space is independently checked using the full third-rank Hall tensor, and direction coverage is sampled on every axis and plane as well as generic orientations.
\end{minipage}
\clearpage
{\Large\bfseries Complete table, in Table S7 order}\par
\small First three columns are merged across all direction branches of one cSLG. Asterisks refer to Appendix A.\par
\vspace{3mm}
\fontsize{8.5}{10}\selectfont
\setlength{\tabcolsep}{1.1mm}
\newcolumntype{C}[1]{w{c}{#1}}
\newcolumntype{L}[1]{w{l}{#1}}
\setbox\strutbox\hbox{\vrule height7pt depth3pt width0pt}
'''
parts=[header]
columns=r'@{}C{28mm} C{24mm} C{40mm} C{24mm} C{28mm} L{210mm} C{11mm} C{11mm}@{}'
heading=r'\shortstack{cSLG label\\and symbol} & \shortstack{Nonrelativistic\\class} & Operation in SLG & \shortstack{N\'eel\\direction} & \shortstack{SOC MLG\\symbol and number} & Operation in MLG & $\chi_{xyy}^{t,b}$ & $\chi_{yxx}^{t,b}$ \\'
used=0
page_number=0
for g in results:
 n=len(g['branches']);hexa=int(g['id'].split('.')[0])>=65;no=g['ordinal']
 spinops=pointops(cat[g['id']])
 rowheight=max(23,(14*len(spinops)+10)/n)
 groupheight=n*rowheight+0.3*(n-1)+7
 if used==0 or used+groupheight>680:
  if used:parts.append(r'\clearpage'+ '\n')
  page_number+=1
  parts.append(r'\noindent\begin{tabular}{'+columns+'}'+r'\toprule'+heading+r'\midrule\end{tabular}\par\vspace{-4pt}'+'\n')
  used=0
 parts.append(r'\noindent\begin{minipage}{\textwidth}\renewcommand{\arraystretch}{'+str(rowheight/10)+r'}\setlength{\aboverulesep}{0pt}\setlength{\belowrulesep}{0pt}\begin{tabular}{'+columns+'}'+'\n')
 used+=groupheight
 scell=r'\begin{gathered}'+r'\\[1pt]'.join(r'\{'+str(s)+r'\Vert '+op_symbol(label,hexa)+r'\}'for s,R,label in spinops)+r'\end{gathered}'
 audit=' ('+notes[no]+')'if no in notes else ''
 first=r'\multirow{'+str(n)+r'}{28mm}{\centering\shortstack{\textbf{'+f'{no:02d}'+r'}'+audit+r'\\$'+g['id']+r'$\\[2pt]$'+hm(cat[g['id']],True)+r'$\\[2pt]{\scriptsize SI p.~'+str(g['label_page'])+r'}}}'
 second=r'\multirow{'+str(n)+r'}{24mm}{\centering AM}'
 third=r'\multirow{'+str(n)+r'}{40mm}{\centering\fontsize{8}{9}\selectfont$'+scell+'$}'
 for j,b in enumerate(g['branches']):
  d=direction(b)+(r'^{*}'if b['coupled']else '')
  m=cat[b['mlg_id']];mcell=r'\shortstack{$'+hm(m)+r'$\\$'+b['mlg_id']+'$}'
  fields=[first if j==0 else '',second if j==0 else '',third if j==0 else '',r'\rowstrut $'+d+'$',mcell,r'\fitops{'+mlg_ops(b,hexa)+'}','$'+b['flags'][0]+'$','$'+b['flags'][1]+'$']
  parts.append(' & '.join(fields)+r'\\'+'\n')
  if j<n-1:parts.append(r'\cmidrule(l){4-8}'+'\n')
 parts.append(r'\bottomrule\end{tabular}\end{minipage}\par\vspace{-4pt}'+'\n')
parts.append(r'''\clearpage
{\Large\bfseries Appendix A. Complete coupled-component constraints}\par
\normalsize $A^\ell=\chi^\ell_{xyy}$, $B^\ell=\chi^\ell_{yxx}$. Each row below gives the entire allowed linear space for a starred branch, with independent real parameters $u$ or $u_1,u_2$. These relations supplement the $+,-,0,v$ flags; they are not additional assumptions.
\vspace{3mm}
\small
\begin{longtable}{@{}c c c l@{}}
\toprule No. & cSLG label & N\'eel direction & Complete allowed space\\\midrule\endfirsthead
\toprule No. & cSLG label & N\'eel direction & Complete allowed space\\\midrule\endhead
\bottomrule\endfoot
''')
for g in results:
 for b in g['branches']:
  if b['coupled']:parts.append(str(g['ordinal'])+' & $'+g['id']+'$ & $'+direction(b)+'$ & $'+basis_tex(b)+r'$\\[4pt]'+'\n')
parts.append(r'\end{longtable}\end{document}')
(ROOT/'AM_92_cSLG_Neel_MLG_INH.tex').write_text(''.join(parts))
# Plain structured deliverable includes all constraints, complete affine witnesses and source operations.
for g in results:
 g['symbol_latex']=hm(cat[g['id']],True)
 for b in g['branches']:
  b['mlg_symbol_latex']=hm(cat[b['mlg_id']]);b['direction_latex']=direction(b);b['complete_constraint_latex']=basis_tex(b)
(ROOT/'AM_92_results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
print('Generated',len(results),'group tables and',sum(b['coupled']for g in results for b in g['branches']),'coupled rows')
