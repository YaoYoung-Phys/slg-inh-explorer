from format_symbols import *
import csv
results=json.loads((ROOT/'calculation_results.json').read_text())
cat={g['id']:g for g in corrected_catalog()}
notes={77:'S1'}
header=r'''\documentclass[10pt]{article}
\usepackage[paperwidth=420mm,paperheight=297mm,margin=11mm]{geometry}
\usepackage[T1]{fontenc}
\usepackage{lmodern,amsmath,amssymb,array,multirow,booktabs,longtable,graphicx}
\usepackage[hidelinks,pdftitle={80 FM/FIM cSLGs: Magnetic-axis directions, SOC MLGs and hidden INH}]{hyperref}
\pagestyle{plain}
\setlength{\footskip}{18pt}
\setlength{\parindent}{0pt}
\setlength{\parskip}{4pt}
\setlength{\LTpre}{0pt}\setlength{\LTpost}{0pt}
\newcommand{\fitops}[1]{\begingroup\setbox0=\hbox{\fontsize{8}{9}\selectfont$#1$}\ifdim\wd0>210mm\typeout{WIDE-OPS: \the\wd0}\resizebox{210mm}{!}{\box0}\else\box0\fi\endgroup}
\newcommand{\rowstrut}{}
\begin{document}
\begin{minipage}{300mm}
{\LARGE\bfseries 80 FM/FIM collinear spin layer groups}\par
{\Large Magnetic-axis directions, SOC magnetic layer groups and layer-resolved intrinsic nonlinear Hall constraints}\par
\vspace{4mm}
\textbf{Coverage.} All 80 entries of Table S3, in the original order, expanded into \textbf{540 direction branches}: 2 groups have 1 branch, 2 have 2, 23 have 3, 30 have 7, 6 have 8, 12 have 11, and 5 have 15. Directions related by a parent symmetry are retained in the fixed source coordinate setting so that the displayed tensor indices stay meaningful. These 540 rows are direction strata, not 540 distinct MLG types.

\textbf{Source.} J.-X. Du, S. Zeng and Y.-J. Zhao, \textit{Stacking theory for bilayer two-dimensional magnets}, Phys. Rev. B \textbf{113}, 214455 (2026), DOI: \href{https://doi.org/10.1103/g471-xrkl}{10.1103/g471-xrkl}; Supplemental Material, Table S3, pp.~21--33. The source supplies the cSLGs and operations. The magnetic-axis branches, SOC MLGs and response constraints in this report are calculated results.

\textbf{Magnetic axis.} Here $\hat{\mathbf m}$ is the common collinear magnetic axis, which can be chosen along the net magnetization when it is nonzero. For ferrimagnets, sublattice moments keep their relative signs and magnitudes while the common axis is rotated. This definition also covers compensated ferrimagnets; a nonzero net moment is not assumed. The cSLG alone does not distinguish FM from FIM or determine the moment magnitudes. The direction column therefore refers to the magnetic axis rather than a N\'eel vector.

\textbf{Direction notation.} $\mathrm{AX}_{[uvw]}$ denotes a special axis; $\mathrm{PL}_{(hkl)}$ denotes a direction in a special plane excluding all axes lying in that plane; $\mathrm{GEN}$ denotes a direction outside every listed axis and plane. Only symmetry-distinct stabilizer strata of a given group are introduced; for example, groups $1.1.1$ and $2.1.4$ have a single $\mathrm{GEN}$ row that covers all directions; groups $65.1.462$ and $66.1.464$ need only $\mathrm{AX}_{[001]}$ and $\mathrm{GEN}$.

\textbf{Coordinates.} Tensor components are Cartesian, with $z$ normal to the layer. For rectangular and tetragonal groups, $x\parallel\mathbf a$, $y\parallel\mathbf b$. For hexagonal groups, $\mathbf a=(1,0,0)$ and $\mathbf b=(-1/2,\sqrt3/2,0)$, while Cartesian $y\parallel\hat z\times\mathbf a$. Miller indices refer to these crystallographic bases. Thus $[010]$ is not the Cartesian $y$ direction in the hexagonal setting. Hexagonal in-plane operations are displayed with explicit crystallographic directions; $M_{[uvw]}$ has its Cartesian normal along $[uvw]$. The source triplets $\{x,y,xy\}$ and $\{1,2,3\}$ correspond as sets to $\{[100],[010],[110]\}$ and $\{[1\bar10],[120],[210]\}$. No individual identification of the source's numbered subscripts is needed.

\textbf{Operation columns.} Translation parts are omitted and repeated point operations are merged. All distinct nontrivial-part SLG point operations are shown on separate lines; the common spin-only factor is implicit. Every MLG row explicitly lists its point operations on one line. Full MLG symbols and numbers are nevertheless identified from the full affine operations in the source, then verified by a basis/origin change preserving the layer normal. MLG symbols use their standard settings; the explicitly listed operations and tensor indices remain in the source coordinate setting. An affine witness for every row is included in the data package. Omitting translations from the displayed columns does not redefine these group identifiers.

\textbf{Tensor convention.} Set $A^\ell=\chi^\ell_{xyy}$ and $B^\ell=\chi^\ell_{yxx}$ for $\ell=t,b$, with $\chi_{abc}=-\chi_{bac}$ and in-plane indices. Then $\chi_{xyx}=-B$, $\chi_{yxy}=-A$, and all other in-plane entries vanish. The two-component vector $\mathbf v^\ell=(A^\ell,B^\ell)$ transforms as $\mathbf v^{g\ell}=q_g R_\parallel\mathbf v^\ell$. This statement is specific to the $\mathcal T$-odd intrinsic Hall part.

\begin{tabular}{cll}\toprule
Mark & Constraint on the displayed component & Meaning\\\midrule
$+$ & $\chi^t=\chi^b$, allowed & Equal layer contributions\\
$-$ & $\chi^t=-\chi^b$, allowed & Hidden, layer compensated\\
$0$ & $\chi^t=\chi^b=0$ & Forbidden in each layer\\
$v$ & No fixed proportional relation between the same component in the two layers & See coupled constraints when starred\\\bottomrule
\end{tabular}

A star on a direction indicates additional relations between $A$ and $B$, listed completely in Appendix A (112 branches). In these rows, $v$ must not be read as absence of all symmetry relations: cross-component relations may remain. All allowed values can accidentally vanish microscopically.

\textbf{Assumptions and calculation.} Fixed structure and collinear order; two physical layers at opposite sides of $z=0$. All nontrivial-part spin labels are $s_g=+1$. The SOC subgroup satisfies $q_g\det(R_g)R_g\hat{\mathbf m}=\hat{\mathbf m}$, with $q_g=+1$ for $g$ and $q_g=-1$ for $g\mathcal T$. Operations with $R_{zz}=-1$ exchange the two layers. Branches are constructed from all real $\pm1$ eigenspaces and their intersections. These are symmetry-allowed constrained orientations, not predictions of magnetic easy axes or stability.

\textbf{Source audit (S1).} Target $77.1.505$ (Table S3, p.~32), operation 09, is printed as $\{-1\Vert M_y\}$. This contradicts the FM/FIM classification, the all-$+1$ spin labels in its symbol, and group closure: two $+1$ operations cannot produce an isolated $-1$ operation. We use $\{+1\Vert M_y\}$; all 80 target operation lists then close and agree with the printed group symbols. The original operation is retained in the raw data. This is a consistency repair, not an author-issued erratum.

The MLG reference catalog additionally retains two previously documented consistency repairs: $31.5.192$, operation 04, $s_{M_x}=+1$; and $39.5.260$, operation 08, translation $(0,1/2,0)$. These two records are outside the 80 FM/FIM targets.

\textbf{Validation.} All 540 MLG assignments are checked against complete affine operations. Each allowed response space is independently checked using the full third-rank Hall tensor, and direction coverage is sampled on every axis and plane as well as generic orientations.
\end{minipage}
\clearpage
{\Large\bfseries Complete table, in Table S3 order}\par
\small First three columns are merged across all direction branches of one cSLG. Asterisks refer to Appendix A; S1 refers to the source audit on the first page.\par
\vspace{3mm}
\fontsize{8.5}{10}\selectfont
\setlength{\tabcolsep}{1.1mm}
\newcolumntype{C}[1]{w{c}{#1}}
\newcolumntype{L}[1]{w{l}{#1}}
\setbox\strutbox\hbox{\vrule height7pt depth3pt width0pt}
'''
parts=[header]
columns=r'@{}C{28mm} C{24mm} C{40mm} C{24mm} C{28mm} L{210mm} C{11mm} C{11mm}@{}'
heading=r'\shortstack{cSLG label\\and symbol} & \shortstack{Nonrelativistic\\class} & Operation in SLG & \shortstack{Magnetic-axis\\direction} & \shortstack{SOC MLG\\symbol and number} & Operation in MLG & $\chi_{xyy}^{t,b}$ & $\chi_{yxx}^{t,b}$ \\'
used=0
page_number=0
for g in results:
 n=len(g['branches']);hexa=int(g['id'].split('.')[0])>=65;no=g['ordinal']
 spinops=pointops(cat[g['id']])
 rowheight=max(23,(14*len(spinops)+10)/n,60/n)
 groupheight=n*rowheight+0.3*(n-1)+7
 if used==0 or used+groupheight>680:
  if used:parts.append(r'\clearpage'+ '\n')
  page_number+=1
  parts.append(r'\noindent\begin{tabular}{'+columns+'}'+r'\toprule'+heading+r'\midrule\end{tabular}\par\vspace{-4pt}'+'\n')
  used=0
 parts.append(r'\noindent\begin{minipage}{\textwidth}\renewcommand{\arraystretch}{'+str(rowheight/10)+r'}\setlength{\aboverulesep}{0pt}\setlength{\belowrulesep}{0pt}\begin{tabular}{'+columns+'}'+'\n')
 used+=groupheight
 scell=r'\begin{gathered}'+r'\\[1pt]'.join(r'\{'+str(s)+r'\Vert '+op_symbol(label,hexa)+r'\}'for s,R,label in spinops)+r'\end{gathered}'
 audit=' ('+notes[no]+')'if no in notes else ''
 first=r'\multirow{'+str(n)+r'}{28mm}{\centering\shortstack{\textbf{'+f'{no:02d}'+r'}'+audit+r'\\$'+g['id']+r'$\\[2pt]$'+hm(cat[g['id']],True)+r'$\\[2pt]{\scriptsize SI p.~'+str(g['label_page'])+r'}}}'
 second=r'\multirow{'+str(n)+r'}{24mm}{\centering FM/FIM}'
 third=r'\multirow{'+str(n)+r'}{40mm}{\centering\fontsize{8}{9}\selectfont$'+scell+'$}'
 for j,b in enumerate(g['branches']):
  d=direction(b)+(r'^{*}'if b['coupled']else '')
  m=cat[b['mlg_id']];mcell=r'\shortstack{$'+hm(m)+r'$\\$'+b['mlg_id']+'$}'
  fields=[first if j==0 else '',second if j==0 else '',third if j==0 else '',r'\rowstrut $'+d+'$',mcell,r'\fitops{'+mlg_ops(b,hexa)+'}','$'+b['flags'][0]+'$','$'+b['flags'][1]+'$']
  parts.append(' & '.join(fields)+r'\\'+'\n')
  if j<n-1:parts.append(r'\cmidrule(l){4-8}'+'\n')
 parts.append(r'\bottomrule\end{tabular}\end{minipage}\par\vspace{-4pt}'+'\n')
parts.append(r'''\clearpage
{\Large\bfseries Appendix A. Complete coupled-component constraints}\par
\normalsize $A^\ell=\chi^\ell_{xyy}$, $B^\ell=\chi^\ell_{yxx}$. Each row below gives the entire allowed linear space for a starred branch, with independent real parameters $u$ or $u_1,u_2$. These relations supplement the $+,-,0,v$ flags; they are not additional assumptions.
\vspace{3mm}
\small
\begin{longtable}{@{}c c c l@{}}
\toprule No. & cSLG label & Magnetic-axis direction & Complete allowed space\\\midrule\endfirsthead
\toprule No. & cSLG label & Magnetic-axis direction & Complete allowed space\\\midrule\endhead
\bottomrule\endfoot
''')
for g in results:
 for b in g['branches']:
  if b['coupled']:parts.append(str(g['ordinal'])+' & $'+g['id']+'$ & $'+direction(b)+'$ & $'+basis_tex(b)+r'$\\[4pt]'+'\n')
parts.append(r'\end{longtable}\end{document}')
(ROOT/'FM_FIM_80_cSLG_Maxis_MLG_INH.tex').write_text(''.join(parts))
# Plain structured deliverable includes all constraints, complete affine witnesses and source operations.
for g in results:
 g['symbol_latex']=hm(cat[g['id']],True)
 for b in g['branches']:
  b['mlg_symbol_latex']=hm(cat[b['mlg_id']]);b['direction_latex']=direction(b);b['complete_constraint_latex']=basis_tex(b)
(ROOT/'FM_FIM_80_results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
print('Generated',len(results),'group tables and',sum(b['coupled']for g in results for b in g['branches']),'coupled rows')
