import re,json,subprocess,sys
from pathlib import Path
root=Path(__file__).parent
source=Path(sys.argv[1]) if len(sys.argv)>1 else root/'Supplemental_Materials_of_magnetic_stacking_theory.pdf'
if not source.is_file(): raise SystemExit('Pass the Supplemental Materials PDF path as the first argument. Raw extracted JSON is already bundled.')
txt=subprocess.check_output(['pdftotext','-layout',str(source),'-']).decode()
lines=txt.splitlines(); groups=[]; current=None; table=None; page=1
op_re=re.compile(r'(\d\d):\s*\{(-?1)\|\|([^|]+)\|([^}]+)\}')
id_re=re.compile(r'^\s*(\d+\.\d+\.\d+)\s+(\S+)')
# Retain literal source strings; scientific corrections are a separate layer.
for pi,pt in enumerate(txt.split('\f'),1):
 for line in pt.splitlines():
  if re.match(r'Table S[3-7] The',line):table=int(re.match(r'Table S([3-7])',line)[1])
  if table is None:continue
  om=op_re.search(line); im=id_re.search(line)
  if om and int(om[1])==1:
   if current: groups.append(current)
   current={'table':table,'page':pi,'operations':[]}
  if current is not None:
   if im:current.update(id=im[1],symbol_raw=im[2],label_page=pi)
   if om:current['operations'].append({'index':int(om[1]),'s':int(om[2]),'label':om[3].replace(' ',''),'translation':om[4].replace(' ',''),'page':pi})
if current:groups.append(current)
assert len(groups)==448,len(groups)
assert all('id'in g for g in groups)
assert len({g['id'] for g in groups})==448
assert all([o['index'] for o in g['operations']]==list(range(1,len(g['operations'])+1)) for g in groups)
(root/'source_catalog_448.json').write_text(json.dumps(groups,ensure_ascii=False,indent=2))
target=[g for g in groups if g['table']==7]
assert len(target)==92,len(target)
(root/'source_am_92.json').write_text(json.dumps(target,ensure_ascii=False,indent=2))
for i,g in enumerate(target,1):print(i,g['id'],g['symbol_raw'],len(g['operations']),g['page'])
print('LABELS',sorted({o['label'] for g in groups for o in g['operations']}))
