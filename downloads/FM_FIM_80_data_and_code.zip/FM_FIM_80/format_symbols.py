from symmetry_core import *
# Standard-setting Hermann-Mauguin tokens with their source point-operation labels.
def tok(symbol,label):return (symbol,label)
E=('1','1');X=('2','2x');Y=('2','2y');Z=('2','2z');MX=('m','mx');MY=('m','my');MZ=('m','mz')
SPEC={1:('p',[E]),2:('p',[(r'\bar1','1̅')]),3:('p',[E,E,Z]),4:('p',[E,E,MZ]),5:('p',[E,E,('a','mz')]),
6:('p',[E,E,Z,'/',MZ]),7:('p',[E,E,Z,'/',('a','mz')]),8:('p',[X,E,E]),9:('p',[(r'2_1','2x'),E,E]),10:('c',[X,E,E]),
11:('p',[MX,E,E]),12:('p',[('b','mx'),E,E]),13:('c',[MX,E,E]),14:('p',[X,'/',MX,E,E]),15:('p',[(r'2_1','2x'),'/',MX,E,E]),
16:('p',[X,'/',('b','mx'),E,E]),17:('p',[(r'2_1','2x'),'/',('b','mx'),E,E]),18:('c',[X,'/',MX,E,E]),
19:('p',[X,Y,Z]),20:('p',[(r'2_1','2x'),Y,Z]),21:('p',[(r'2_1','2x'),(r'2_1','2y'),Z]),22:('c',[X,Y,Z]),
23:('p',[MX,MY,Z]),24:('p',[MX,('a','my'),Z]),25:('p',[('b','mx'),('a','my'),Z]),26:('c',[MX,MY,Z])}
for num,lat,sym in [(27,'p',['m','2','m']),(28,'p',['m','2_1','b']),(29,'p',['b','2_1','m']),(30,'p',['b','2','b']),(31,'p',['m','2','a']),(32,'p',['m','2_1','n']),(33,'p',['b','2_1','a']),(34,'p',['b','2','n']),(35,'c',['m','2','m']),(36,'c',['m','2','a'])]:SPEC[num]=(lat,list(zip(sym,['mx','2y','mz'])))
for num,lat,sym in [(37,'p','mmm'),(38,'p','maa'),(39,'p','ban'),(40,'p','mam'),(41,'p','mma'),(42,'p','man'),(43,'p','baa'),(44,'p','bam'),(45,'p','bma'),(46,'p','mmn'),(47,'c','mmm'),(48,'c','mme')]:SPEC[num]=(lat,list(zip(sym,['mx','my','mz'])))
SPEC.update({73:('p',[('6','6z')]),74:('p',[(r'\bar6','6̅z')]),75:('p',[('6','6z'),'/',MZ]),
76:('p',[('6','6z'),('2','2x'),('2','21')]),77:('p',[('6','6z'),('m','mx'),('m','m1')]),
78:('p',[(r'\bar6','6̅z'),('m','mx'),('2','21')]),79:('p',[(r'\bar6','6̅z'),('2','2x'),('m','m1')]),
80:('p',[('6','6z'),'/',MZ,('m','mx'),('m','m1')])})

C4=('4','4z');B4=(r'\bar4','4̅z');D2=('2','2xy');DM=('m','mxy');S2=(r'2_1','2x');BX=('b','mx');NZ=('n','mz');C3=('3','3z');B3=(r'\bar3','3̅z')
SPEC.update({
49:('p',[C4]),50:('p',[B4]),51:('p',[C4,'/',MZ]),52:('p',[C4,'/',NZ]),
53:('p',[C4,X,D2]),54:('p',[C4,S2,D2]),55:('p',[C4,MX,DM]),56:('p',[C4,BX,DM]),
57:('p',[B4,X,DM]),58:('p',[B4,S2,DM]),59:('p',[B4,MX,D2]),60:('p',[B4,BX,D2]),
61:('p',[C4,'/',MZ,MX,DM]),62:('p',[C4,'/',NZ,BX,DM]),63:('p',[C4,'/',MZ,BX,DM]),64:('p',[C4,'/',NZ,MX,DM]),
65:('p',[C3]),66:('p',[B3]),67:('p',[C3,E,('2','21')]),68:('p',[C3,X,E]),
69:('p',[C3,MX,E]),70:('p',[C3,E,('m','m1')]),71:('p',[B3,E,('m','m1')]),72:('p',[B3,MX,E])})

def hm(g,spin=False):
 signs={normlabel(o['label']):o['s']for o in g['operations']}
 lat,seq=SPEC[int(g['id'].split('.')[0])];out=lat
 for token in seq:
  if token=='/':out+='/';continue
  sym,label=token;s=signs[label]
  if spin:out+='^{'+str(s)+'}'+sym
  else:out+=sym+("'"if s==-1 else '')
 return out

def idx(v):
 return ''.join(str(x)if x>=0 else r'\bar{'+str(-x)+'}'for x in v)
def direction(b):
 if b['kind']=='GEN':return r'\mathrm{GEN}'
 brace='['+idx(b['indices'])+']'if b['kind']=='AX'else '('+idx(b['indices'])+')'
 return r'\mathrm{'+b['kind']+'}_{'+brace+'}'

def op_symbol(label,hexa=False):
 label=normlabel(label)
 if label=='1':return 'E'
 if label=='1̅':return r'\mathcal P'
 if label.startswith('m')or(label.startswith('2')and label!='2z'):
  a=label[1:]
  if hexa and a!='z':
   suffix='['+idx(DIRECTIONS[a])+']'
   return ('M_{'+suffix+'}'if label.startswith('m')else 'C_{2,'+suffix+'}')
  if a=='xby':a=r'\bar{x}y'
  return ('M_{'+a+'}'if label.startswith('m')else 'C_{2'+a+'}')
 n=label[0];bar='̅'in label;power='^{-1}'if label.endswith('-1')else ''
 return (r'\bar C'if bar else 'C')+'_{'+n+'z}'+power

def mlg_ops(b,hexa):
 return r'\{'+r',\,'.join(op_symbol(o['label'],hexa)+(r'\mathcal T'if o['q']==-1 else '')for o in b['operations'])+r'\}'

def basis_tex(b):
 N=S.Matrix([[S.sympify(x)for x in row]for row in b['basis']])if b['dimension']else S.zeros(4,0)
 if not N.cols:return r'(A^t,B^t,A^b,B^b)=(0,0,0,0)'
 terms=[]
 for j in range(N.cols):
  # Scale each basis vector to short integer / sqrt(3) entries when convenient.
  v=N[:,j]
  den=S.ilcm(*[S.denom(x)for x in v]);v=S.simplify(v*den)
  if any(x.has(S.sqrt(3))for x in v)and any(S.denom(x).has(S.sqrt(3))for x in v):v=S.simplify(v*S.sqrt(3))
  terms.append(('u'if N.cols==1 else 'u_{'+str(j+1)+'}')+r'\bigl('+r',\,'.join(S.latex(x)for x in v)+r'\bigr)')
 return '(A^t,B^t,A^b,B^b)='+ '+'.join(terms)
